"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  images: string[]
  category: string
  creatorName: string
  creatorId: string
  description: string
  trending?: boolean
  rating: number
  reviews: number
  sizes: string[]
  colors: string[]
}

export function TrendingProducts() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simple mock data to avoid localStorage issues
    const mockData: Product[] = [
      {
        id: "1",
        name: "Premium Wireless Earbuds",
        price: 2999,
        images: ["/placeholder.svg?height=200&width=200"],
        category: "other",
        creatorName: "monsoon_kart",
        creatorId: "1",
        description: "High-quality wireless earbuds with noise cancellation and long battery life.",
        trending: true,
        rating: 4.7,
        reviews: 128,
        sizes: [],
        colors: [],
      },
      {
        id: "2",
        name: "Designer Denim Jacket",
        price: 4999,
        images: ["/placeholder.svg?height=200&width=200"],
        category: "fashion",
        creatorName: "monsoon_kart",
        creatorId: "1",
        description: "Stylish denim jacket perfect for casual outings.",
        trending: true,
        rating: 4.9,
        reviews: 87,
        sizes: ["S", "M", "L", "XL"],
        colors: ["Blue", "Black", "White"],
      },
      {
        id: "3",
        name: "Natural Skincare Set",
        price: 1999,
        images: ["/placeholder.svg?height=200&width=200"],
        category: "beauty",
        creatorName: "monsoon_kart",
        creatorId: "1",
        description: "Complete skincare routine with natural ingredients.",
        trending: true,
        rating: 4.8,
        reviews: 215,
        sizes: [],
        colors: [],
      },
      {
        id: "4",
        name: "Smart Fitness Watch",
        price: 3499,
        images: ["/placeholder.svg?height=200&width=200"],
        category: "other",
        creatorName: "monsoon_kart",
        creatorId: "1",
        description: "Track your fitness goals with this advanced smartwatch.",
        trending: true,
        rating: 4.6,
        reviews: 156,
        sizes: [],
        colors: [],
      },
    ]

    setProducts(mockData)
    setLoading(false)
  }, [])

  if (loading) {
    return <div className="text-center py-10">Loading trending products...</div>
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          <Link href={`/product/${product.id}`}>
            <div className="relative h-40 md:h-48">
              <Image src={product.images[0] || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
            </div>
          </Link>
          <div className="p-3">
            <Link href={`/product/${product.id}`}>
              <h3 className="font-medium text-sm truncate hover:text-[#6366f1]">{product.name}</h3>
            </Link>
            <div className="flex items-center mt-1 mb-1">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={14}
                    className={star <= Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
                  />
                ))}
              </div>
              <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
            </div>
            <div className="flex justify-between items-center mt-1">
              <span className="font-bold text-[#6366f1]">₹{product.price}</span>
              <span className="text-xs text-gray-500">{product.creatorName}</span>
            </div>
            <Link href={`/product/${product.id}`}>
              <Button className="w-full mt-2 bg-[#6366f1] hover:bg-[#5457e5]" size="sm">
                Buy Now
              </Button>
            </Link>
          </div>
        </div>
      ))}
    </div>
  )
}
