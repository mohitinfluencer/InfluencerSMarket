"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { addOrder, indianStates, getProductById } from "@/lib/data"

interface OrderFormProps {
  productId: string
}

export function OrderForm({ productId }: OrderFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const product = getProductById(productId)
  const [formData, setFormData] = useState({
    fullName: "",
    address: "",
    mobile: "",
    pincode: "",
    email: "",
    state: "",
  })
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    product?.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined,
  )
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product?.colors && product.colors.length > 0 ? product.colors[0] : undefined,
  )

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Add order to data store
      addOrder({
        productId,
        userInfo: formData,
        productDetails: {
          size: selectedSize,
          color: selectedColor,
        },
      })

      toast({
        title: "Order placed successfully!",
        description: "Your order has been placed and will be processed soon",
      })

      // Clear form
      setFormData({
        fullName: "",
        address: "",
        mobile: "",
        pincode: "",
        email: "",
        state: "",
      })

      // Redirect to orders page
      setTimeout(() => {
        router.push("/orders")
      }, 1500)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Complete Your Order</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="fullName" className="text-sm font-medium">
              Full Name *
            </label>
            <Input
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Enter your full name"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="address" className="text-sm font-medium">
              Address *
            </label>
            <Input
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Enter your complete address"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="mobile" className="text-sm font-medium">
              Mobile *
            </label>
            <Input
              id="mobile"
              name="mobile"
              value={formData.mobile}
              onChange={handleChange}
              placeholder="Enter your mobile number"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="pincode" className="text-sm font-medium">
                Pincode *
              </label>
              <Input
                id="pincode"
                name="pincode"
                value={formData.pincode}
                onChange={handleChange}
                placeholder="Enter pincode"
                required
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="state" className="text-sm font-medium">
                State *
              </label>
              <Select
                value={formData.state}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, state: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent className="max-h-[200px]">
                  {indianStates.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="email" className="text-sm font-medium">
              Email *
            </label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              required
            />
          </div>

          {product?.sizes && product.sizes.length > 0 && (
            <div className="space-y-2">
              <label htmlFor="size" className="text-sm font-medium">
                Size *
              </label>
              <Select value={selectedSize} onValueChange={setSelectedSize} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  {product.sizes.map((size) => (
                    <SelectItem key={size} value={size}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {product?.colors && product.colors.length > 0 && (
            <div className="space-y-2">
              <label htmlFor="color" className="text-sm font-medium">
                Color *
              </label>
              <Select value={selectedColor} onValueChange={setSelectedColor} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select color" />
                </SelectTrigger>
                <SelectContent>
                  {product.colors.map((color) => (
                    <SelectItem key={color} value={color}>
                      {color}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <div className="flex items-center">
              <div className="w-6 h-6 rounded-full border-2 border-[#6366f1] flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-[#6366f1]"></div>
              </div>
              <span className="ml-2 font-medium">Cash on Delivery</span>
            </div>
            <p className="text-sm text-gray-500 mt-1 ml-8">Pay when your order arrives</p>
          </div>

          <Button type="submit" className="w-full bg-[#6366f1] hover:bg-[#5457e5]" disabled={isLoading}>
            {isLoading ? "Placing Order..." : "Place Order"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
