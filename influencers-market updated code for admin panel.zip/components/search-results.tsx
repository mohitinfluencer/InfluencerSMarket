"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { searchProducts, searchInfluencers } from "@/lib/data"
import type { Product, Influencer } from "@/lib/types"

interface SearchResultsProps {
  query: string
}

export function SearchResults({ query }: SearchResultsProps) {
  const [products, setProducts] = useState<Product[]>([])
  const [influencers, setInfluencers] = useState<Influencer[]>([])

  useEffect(() => {
    if (query.length > 2) {
      setProducts(searchProducts(query))
      setInfluencers(searchInfluencers(query))
    } else {
      setProducts([])
      setInfluencers([])
    }
  }, [query])

  if (query.length < 3) {
    return <div className="text-center py-10 text-gray-500">Enter at least 3 characters to search</div>
  }

  return (
    <Tabs defaultValue="products">
      <TabsList className="grid w-full grid-cols-2 mb-6">
        <TabsTrigger value="products">Products ({products.length})</TabsTrigger>
        <TabsTrigger value="influencers">Influencers ({influencers.length})</TabsTrigger>
      </TabsList>

      <TabsContent value="products">
        {products.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No products found</div>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {products.map((product) => (
              <div key={product.id} className="border rounded-lg overflow-hidden bg-white">
                <div className="relative h-40">
                  <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm truncate">{product.name}</h3>
                  <div className="flex justify-between items-center mt-1">
                    <span className="font-bold">₹{product.price}</span>
                    <span className="text-xs text-gray-500">{product.creatorName}</span>
                  </div>
                  <Link href={`/product/${product.id}`}>
                    <Button className="w-full mt-2" size="sm">
                      Buy Now
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="influencers">
        {influencers.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No influencers found</div>
        ) : (
          <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
            {influencers.map((influencer) => (
              <Link href={`/influencer/${influencer.id}`} key={influencer.id}>
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-primary mb-2">
                    <Image
                      src={influencer.profileImage || "/placeholder.svg"}
                      alt={influencer.name}
                      width={80}
                      height={80}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <h3 className="font-medium text-center">{influencer.name}</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-1"
                    onClick={(e) => {
                      e.preventDefault()
                      window.open(influencer.profileUrl, "_blank")
                    }}
                  >
                    Follow
                  </Button>
                </div>
              </Link>
            ))}
          </div>
        )}
      </TabsContent>
    </Tabs>
  )
}
