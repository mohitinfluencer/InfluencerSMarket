"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, ShoppingBag, User, ShoppingCart } from "lucide-react"

export function UserBottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2 z-10">
      <Link
        href="/"
        className={`flex flex-col items-center p-2 ${pathname === "/" ? "text-primary" : "text-gray-500"}`}
      >
        <Home size={20} />
        <span className="text-xs mt-1">Home</span>
      </Link>

      <Link
        href="/search"
        className={`flex flex-col items-center p-2 ${pathname === "/search" ? "text-primary" : "text-gray-500"}`}
      >
        <Search size={20} />
        <span className="text-xs mt-1">Search</span>
      </Link>

      <Link
        href="/orders"
        className={`flex flex-col items-center p-2 ${pathname === "/orders" ? "text-primary" : "text-gray-500"}`}
      >
        <ShoppingBag size={20} />
        <span className="text-xs mt-1">Orders</span>
      </Link>

      <Link
        href="/cart"
        className={`flex flex-col items-center p-2 ${pathname === "/cart" ? "text-primary" : "text-gray-500"}`}
      >
        <ShoppingCart size={20} />
        <span className="text-xs mt-1">Cart</span>
      </Link>

      <Link
        href="/profile"
        className={`flex flex-col items-center p-2 ${pathname === "/profile" ? "text-primary" : "text-gray-500"}`}
      >
        <User size={20} />
        <span className="text-xs mt-1">Profile</span>
      </Link>
    </nav>
  )
}
