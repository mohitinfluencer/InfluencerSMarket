"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

interface Influencer {
  id: string
  name: string
  profileImage: string
  profileUrl: string
  followers: string
}

export function InfluencerGrid() {
  const [influencers, setInfluencers] = useState<Influencer[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simple mock data to avoid localStorage issues
    const mockData: Influencer[] = [
      {
        id: "1",
        name: "monsoon_kart",
        profileImage: "/placeholder.svg?height=80&width=80",
        profileUrl: "https://instagram.com/monsoon_kart",
        followers: "2.5M",
      },
    ]

    setInfluencers(mockData)
    setLoading(false)
  }, [])

  if (loading) {
    return <div className="text-center py-10">Loading influencers...</div>
  }

  return (
    <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
      {influencers.map((influencer) => (
        <div
          key={influencer.id}
          className="border rounded-lg p-6 flex flex-col items-center bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          <Link href={`/influencer/${influencer.id}`} className="relative">
            <div className="w-24 h-24 md:w-28 md:h-28 rounded-full overflow-hidden border-2 border-[#6366f1] mb-3">
              <Image
                src={influencer.profileImage || "/placeholder.svg"}
                alt={influencer.name}
                width={112}
                height={112}
                className="object-cover w-full h-full"
              />
            </div>
          </Link>
          <h3 className="font-medium text-center">{influencer.name}</h3>
          <p className="text-sm text-gray-500 mb-3">{influencer.followers} followers</p>
          <Link href={`/influencer/${influencer.id}`}>
            <Button className="bg-[#6366f1] hover:bg-[#5457e5] text-white">Shop From</Button>
          </Link>
        </div>
      ))}
    </div>
  )
}
