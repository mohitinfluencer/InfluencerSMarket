"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { getProductsByInfluencer } from "@/lib/data"
import type { Product } from "@/lib/types"

interface ProductGridProps {
  influencerId: string
  selectedCategory?: string
}

export function ProductGrid({ influencerId, selectedCategory = "all" }: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])

  useEffect(() => {
    const allProducts = getProductsByInfluencer(influencerId)
    setProducts(allProducts)
  }, [influencerId])

  useEffect(() => {
    if (selectedCategory === "all") {
      setFilteredProducts(products)
    } else {
      setFilteredProducts(products.filter((product) => product.category === selectedCategory))
    }
  }, [products, selectedCategory])

  if (filteredProducts.length === 0 && selectedCategory !== "all") {
    return <div className="text-center py-10 text-gray-500">No products found in this category</div>
  }

  if (products.length === 0) {
    return <div className="text-center py-10 text-gray-500">No products found for this influencer</div>
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
      {filteredProducts.map((product) => (
        <div
          key={product.id}
          className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          <Link href={`/product/${product.id}`}>
            <div className="relative h-40 md:h-48">
              <Image
                src={product.images[0] || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement
                  target.src = "/placeholder.svg?height=200&width=200"
                }}
              />
            </div>
          </Link>
          <div className="p-3">
            <Link href={`/product/${product.id}`}>
              <h3 className="font-medium text-sm truncate hover:text-primary">{product.name}</h3>
            </Link>
            <div className="flex justify-between items-center mt-1">
              <span className="font-bold text-primary">₹{product.price}</span>
            </div>
            <Link href={`/product/${product.id}`}>
              <Button className="w-full mt-2" size="sm">
                Buy Now
              </Button>
            </Link>
          </div>
        </div>
      ))}
    </div>
  )
}
