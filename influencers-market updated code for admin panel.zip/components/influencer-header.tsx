"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import type { Influencer } from "@/lib/types"

interface InfluencerHeaderProps {
  influencer: Influencer
}

export function InfluencerHeader({ influencer }: InfluencerHeaderProps) {
  return (
    <div className="flex items-center mb-6">
      <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-primary">
        <Image
          src={influencer.profileImage || "/placeholder.svg"}
          alt={influencer.name}
          fill
          className="object-cover"
        />
      </div>
      <div className="ml-4">
        <h2 className="text-xl font-bold">{influencer.name}</h2>
        <p className="text-gray-500 text-sm">{influencer.followers} followers</p>
        <Button
          variant="outline"
          size="sm"
          className="mt-1"
          onClick={() => window.open(influencer.profileUrl, "_blank")}
        >
          Follow
        </Button>
      </div>
    </div>
  )
}
