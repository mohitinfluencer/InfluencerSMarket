"use client"

import { useState, useEffect } from "react"
import { getUserOrders } from "@/lib/data"
import type { Order } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

export function OrdersList() {
  const [orders, setOrders] = useState<Order[]>([])

  useEffect(() => {
    setOrders(getUserOrders())
  }, [])

  if (orders.length === 0) {
    return <div className="text-center py-10 text-gray-500">You haven't placed any orders yet</div>
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id}>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="relative w-16 h-16 rounded overflow-hidden">
                <Image
                  src={order.product.images[0] || "/placeholder.svg"}
                  alt={order.product.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="ml-4 flex-1">
                <div className="flex justify-between items-start">
                  <h3 className="font-medium">{order.product.name}</h3>
                  <Badge
                    variant={order.status === "pending" ? "outline" : "default"}
                    className={order.status === "pending" ? "border-yellow-500 text-yellow-500" : "bg-green-500"}
                  >
                    {order.status === "pending" ? (
                      <span className="flex items-center">
                        <span className="w-2 h-2 rounded-full bg-yellow-500 mr-1"></span> Pending
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <span className="w-2 h-2 rounded-full bg-white mr-1"></span> Confirmed
                      </span>
                    )}
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Order #{order.id}</p>
                <p className="text-sm font-bold mt-1">₹{order.product.price}</p>
                <p className="text-xs text-gray-500 mt-1">Ordered on {new Date(order.date).toLocaleDateString()}</p>

                {order.productDetails && (
                  <div className="mt-2 text-xs">
                    {order.productDetails.size && <span className="mr-3">Size: {order.productDetails.size}</span>}
                    {order.productDetails.color && <span>Color: {order.productDetails.color}</span>}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
