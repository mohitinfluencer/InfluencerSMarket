"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Order } from "@/lib/types"
import { Search, CheckCircle } from "lucide-react"
import Image from "next/image"

export function AdminOrdersList() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const loadOrders = () => {
      try {
        const stored = localStorage.getItem("allOrders")
        const ordersData = stored ? JSON.parse(stored) : []
        setOrders(ordersData)
        setFilteredOrders(ordersData)
      } catch (error) {
        console.error("Error loading orders:", error)
      }
    }

    loadOrders()

    // Listen for storage changes to refresh orders
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "allOrders" || e.key === null) {
        loadOrders()
      }
    }

    const handleCustomStorageChange = () => {
      loadOrders()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("storage", handleCustomStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("storage", handleCustomStorageChange)
    }
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredOrders(orders)
    } else {
      const filtered = orders.filter(
        (order) =>
          order.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          order.product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          order.product.creatorName.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredOrders(filtered)
    }
  }, [searchQuery, orders])

  const markAsConfirmed = (orderId: string) => {
    try {
      // Update all orders
      const allOrders = JSON.parse(localStorage.getItem("allOrders") || "[]")
      const updatedAllOrders = allOrders.map((order: any) =>
        order.id === orderId ? { ...order, status: "confirmed" } : order,
      )
      localStorage.setItem("allOrders", JSON.stringify(updatedAllOrders))

      // Update user orders
      const userOrders = JSON.parse(localStorage.getItem("userOrders") || "[]")
      const updatedUserOrders = userOrders.map((order: any) =>
        order.id === orderId ? { ...order, status: "confirmed" } : order,
      )
      localStorage.setItem("userOrders", JSON.stringify(updatedUserOrders))

      // Update local state
      const updatedOrders = orders.map((order) =>
        order.id === orderId ? { ...order, status: "confirmed" as const } : order,
      )
      setOrders(updatedOrders)
      setFilteredOrders(
        filteredOrders.map((order) => (order.id === orderId ? { ...order, status: "confirmed" as const } : order)),
      )

      // Trigger storage event
      window.dispatchEvent(new Event("storage"))

      alert(`Order #${orderId} marked as confirmed`)
    } catch (error) {
      alert("Failed to update order status")
    }
  }

  return (
    <div>
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        <Input
          type="text"
          placeholder="Search orders..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No orders found</div>
        ) : (
          filteredOrders.map((order) => (
            <Card key={order.id}>
              <CardContent className="p-4">
                <div className="flex items-center mb-4">
                  <div className="relative w-16 h-16 rounded overflow-hidden">
                    <Image
                      src={order.product.images[0] || "/placeholder.svg"}
                      alt={order.product.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium">{order.product.name}</h3>
                      <Badge
                        variant={order.status === "pending" ? "outline" : "default"}
                        className={order.status === "pending" ? "border-yellow-500 text-yellow-500" : "bg-green-500"}
                      >
                        {order.status === "pending" ? (
                          <span className="flex items-center">
                            <span className="w-2 h-2 rounded-full bg-yellow-500 mr-1"></span> Pending
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <span className="w-2 h-2 rounded-full bg-white mr-1"></span> Confirmed
                          </span>
                        )}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">Order #{order.id}</p>
                    <div className="flex justify-between items-center">
                      <p className="text-sm font-bold mt-1">₹{order.product.price}</p>
                      <p className="text-sm text-[#6366f1] font-medium">Creator: {order.product.creatorName}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Ordered on {new Date(order.date).toLocaleDateString()}</p>

                    {order.productDetails && (
                      <div className="mt-1 text-xs">
                        {order.productDetails.size && <span className="mr-3">Size: {order.productDetails.size}</span>}
                        {order.productDetails.color && <span>Color: {order.productDetails.color}</span>}
                      </div>
                    )}
                  </div>
                </div>

                <div className="border-t pt-4 mt-2">
                  <h4 className="font-medium mb-2">Customer Details</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p className="font-medium">{order.user.name}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-medium">{order.user.email}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-500">Mobile</p>
                      <p className="font-medium">{order.user.mobile}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-500">Address</p>
                      <p className="font-medium">{order.user.address}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-500">Pincode</p>
                      <p className="font-medium">{order.user.pincode}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-500">State</p>
                      <p className="font-medium">{order.user.state}</p>
                    </div>
                  </div>
                </div>

                {order.status === "pending" && (
                  <div className="mt-4 flex justify-end">
                    <Button
                      onClick={() => markAsConfirmed(order.id)}
                      className="flex items-center bg-green-500 hover:bg-green-600"
                    >
                      <CheckCircle className="mr-2" size={16} />
                      Mark as Confirmed
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
