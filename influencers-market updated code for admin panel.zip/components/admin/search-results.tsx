"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { searchProducts, searchInfluencers } from "@/lib/data"
import type { Product, Influencer } from "@/lib/types"
import Image from "next/image"
import { toast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"

interface AdminSearchResultsProps {
  query: string
}

export function AdminSearchResults({ query }: AdminSearchResultsProps) {
  const [products, setProducts] = useState<Product[]>([])
  const [influencers, setInfluencers] = useState<Influencer[]>([])

  useEffect(() => {
    if (query.length > 2) {
      setProducts(searchProducts(query))
      setInfluencers(searchInfluencers(query))
    } else {
      setProducts([])
      setInfluencers([])
    }
  }, [query])

  const handleDelete = (type: "product" | "influencer", id: string) => {
    // In a real app, you'd call an API to delete the item
    if (type === "product") {
      setProducts(products.filter((product) => product.id !== id))
    } else {
      setInfluencers(influencers.filter((influencer) => influencer.id !== id))
    }

    toast({
      title: `${type === "product" ? "Product" : "Influencer"} deleted`,
      description: `The ${type} has been deleted successfully`,
    })
  }

  if (query.length < 3) {
    return <div className="text-center py-10 text-gray-500">Enter at least 3 characters to search</div>
  }

  return (
    <Tabs defaultValue="products">
      <TabsList className="grid w-full grid-cols-2 mb-6">
        <TabsTrigger value="products">Products ({products.length})</TabsTrigger>
        <TabsTrigger value="influencers">Influencers ({influencers.length})</TabsTrigger>
      </TabsList>

      <TabsContent value="products">
        {products.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No products found</div>
        ) : (
          <div className="space-y-4">
            {products.map((product) => (
              <Card key={product.id}>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className="relative w-16 h-16 rounded overflow-hidden">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium">{product.name}</h3>
                        <div className="flex space-x-2">
                          <Button variant="destructive" size="sm" onClick={() => handleDelete("product", product.id)}>
                            Delete
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500">{product.creatorName}</p>
                      <p className="text-sm font-bold mt-1">₹{product.price}</p>
                      <p className="text-xs text-gray-500 mt-1">Category: {product.category}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="influencers">
        {influencers.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No influencers found</div>
        ) : (
          <div className="space-y-4">
            {influencers.map((influencer) => (
              <Card key={influencer.id}>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className="relative w-16 h-16 rounded-full overflow-hidden">
                      <Image
                        src={influencer.profileImage || "/placeholder.svg"}
                        alt={influencer.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium">{influencer.name}</h3>
                        <div className="flex space-x-2">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDelete("influencer", influencer.id)}
                          >
                            Delete
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500">{influencer.followers} followers</p>
                      <p className="text-xs text-gray-500 mt-1">Profile: {influencer.profileUrl}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </TabsContent>
    </Tabs>
  )
}
