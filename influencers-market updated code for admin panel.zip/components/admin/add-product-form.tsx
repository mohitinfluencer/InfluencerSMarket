"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/hooks/use-toast"
import { getInfluencers, addProduct } from "@/lib/data"
import { Upload, X, Plus } from "lucide-react"

export function AddProductForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [imagePreviews, setImagePreviews] = useState<string[]>([])
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    category: "",
    creatorId: "",
    description: "",
    trending: false,
    sizes: [] as string[],
    colors: [] as string[],
  })
  const [showSizeOptions, setShowSizeOptions] = useState(false)
  const [showColorOptions, setShowColorOptions] = useState(false)
  const [newColor, setNewColor] = useState("")

  const influencers = getInfluencers()
  const sizeOptions = ["S", "M", "L", "XL", "XXL"]

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Show size and color options for fashion category
    if (name === "category" && value === "fashion") {
      setShowSizeOptions(true)
      setShowColorOptions(true)
    } else if (name === "category") {
      setShowSizeOptions(false)
      setShowColorOptions(false)
      setFormData((prev) => ({ ...prev, sizes: [], colors: [] }))
    }
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, trending: checked }))
  }

  const handleSizeToggle = (size: string) => {
    setFormData((prev) => {
      if (prev.sizes.includes(size)) {
        return { ...prev, sizes: prev.sizes.filter((s) => s !== size) }
      } else {
        return { ...prev, sizes: [...prev.sizes, size] }
      }
    })
  }

  const handleAddColor = () => {
    if (newColor && !formData.colors.includes(newColor)) {
      setFormData((prev) => ({ ...prev, colors: [...prev.colors, newColor] }))
      setNewColor("")
    }
  }

  const handleRemoveColor = (color: string) => {
    setFormData((prev) => ({ ...prev, colors: prev.colors.filter((c) => c !== color) }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newFiles: File[] = []
    const newPreviews: string[] = []

    for (let i = 0; i < files.length; i++) {
      const file = files[i]

      // Validate file type
      const validTypes = ["image/png", "image/jpg", "image/jpeg"]
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please select PNG or JPG image files only",
          variant: "destructive",
        })
        continue
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select images smaller than 5MB",
          variant: "destructive",
        })
        continue
      }

      newFiles.push(file)

      // Create preview
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          newPreviews.push(event.target.result as string)
          if (newPreviews.length === newFiles.length) {
            setImageFiles((prev) => [...prev, ...newFiles])
            setImagePreviews((prev) => [...prev, ...newPreviews])
          }
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index))
    setImagePreviews((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validate form data
      if (!formData.name || !formData.price || !formData.category || !formData.creatorId || !formData.description) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      if (imagePreviews.length === 0) {
        toast({
          title: "Image Required",
          description: "Please upload at least one product image",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Find creator name
      const creator = influencers.find((inf) => inf.id === formData.creatorId)
      if (!creator) {
        toast({
          title: "Error",
          description: "Selected creator not found",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Create product object
      const newProduct = {
        id: `product_${Date.now()}`,
        name: formData.name,
        price: Number.parseInt(formData.price),
        images: imagePreviews.length > 0 ? imagePreviews : ["/placeholder.svg?height=200&width=200"],
        category: formData.category,
        creatorId: formData.creatorId,
        creatorName: creator.name,
        description: formData.description,
        trending: formData.trending,
        rating: 5.0,
        reviews: 0,
        sizes: formData.sizes,
        colors: formData.colors,
      }

      // Add product to data store
      addProduct(newProduct)

      toast({
        title: "Success!",
        description: "Product has been added successfully",
      })

      // Reset form
      setFormData({
        name: "",
        price: "",
        category: "",
        creatorId: "",
        description: "",
        trending: false,
        sizes: [],
        colors: [],
      })
      setImageFiles([])
      setImagePreviews([])
      setShowSizeOptions(false)
      setShowColorOptions(false)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Product</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="name" className="text-sm font-medium">
              Product Name *
            </label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter product name"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="price" className="text-sm font-medium">
              Price (₹) *
            </label>
            <Input
              id="price"
              name="price"
              type="number"
              min="1"
              value={formData.price}
              onChange={handleChange}
              placeholder="Enter price"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="images" className="text-sm font-medium">
              Product Images * (Upload multiple)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
              <input
                id="images"
                type="file"
                accept=".png,.jpg,.jpeg"
                onChange={handleImageUpload}
                className="hidden"
                multiple
              />
              <label
                htmlFor="images"
                className="flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 p-4 rounded"
              >
                <Upload className="w-12 h-12 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600">Click to upload images</p>
                <p className="text-xs text-gray-400">PNG, JPG up to 5MB (multiple allowed)</p>
              </label>
            </div>

            {imagePreviews.length > 0 && (
              <div className="mt-4">
                <p className="text-sm font-medium mb-2">Uploaded Images:</p>
                <div className="flex flex-wrap gap-3">
                  {imagePreviews.map((preview, index) => (
                    <div key={index} className="relative">
                      <div className="w-20 h-20 relative rounded overflow-hidden">
                        <img
                          src={preview || "/placeholder.svg"}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <button
                        type="button"
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                        onClick={() => removeImage(index)}
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label htmlFor="category" className="text-sm font-medium">
              Category *
            </label>
            <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)} required>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="beauty">Beauty</SelectItem>
                <SelectItem value="other">Other Tools</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {showSizeOptions && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Available Sizes</label>
              <div className="flex flex-wrap gap-2">
                {sizeOptions.map((size) => (
                  <div key={size} className="flex items-center">
                    <Checkbox
                      id={`size-${size}`}
                      checked={formData.sizes.includes(size)}
                      onCheckedChange={() => handleSizeToggle(size)}
                      className="mr-2"
                    />
                    <label htmlFor={`size-${size}`} className="text-sm cursor-pointer">
                      {size}
                    </label>
                  </div>
                ))}
                <div className="flex items-center">
                  <Checkbox
                    id="size-none"
                    checked={formData.sizes.length === 0}
                    onCheckedChange={() => setFormData((prev) => ({ ...prev, sizes: [] }))}
                    className="mr-2"
                  />
                  <label htmlFor="size-none" className="text-sm cursor-pointer">
                    None
                  </label>
                </div>
              </div>
            </div>
          )}

          {showColorOptions && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Available Colors</label>
              <div className="flex items-center space-x-2">
                <Input
                  value={newColor}
                  onChange={(e) => setNewColor(e.target.value)}
                  placeholder="Enter color name"
                  className="flex-1"
                />
                <Button type="button" size="sm" onClick={handleAddColor} className="flex items-center">
                  <Plus size={16} className="mr-1" /> Add
                </Button>
              </div>

              {formData.colors.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.colors.map((color) => (
                    <div key={color} className="bg-gray-100 px-3 py-1 rounded-full flex items-center">
                      <span className="text-sm">{color}</span>
                      <button
                        type="button"
                        className="ml-2 text-gray-500 hover:text-red-500"
                        onClick={() => handleRemoveColor(color)}
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center mt-2">
                <Checkbox
                  id="color-none"
                  checked={formData.colors.length === 0}
                  onCheckedChange={() => setFormData((prev) => ({ ...prev, colors: [] }))}
                  className="mr-2"
                />
                <label htmlFor="color-none" className="text-sm cursor-pointer">
                  No color options
                </label>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label htmlFor="creator" className="text-sm font-medium">
              Creator *
            </label>
            <Select
              value={formData.creatorId}
              onValueChange={(value) => handleSelectChange("creatorId", value)}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select creator" />
              </SelectTrigger>
              <SelectContent>
                {influencers.map((influencer) => (
                  <SelectItem key={influencer.id} value={influencer.id}>
                    {influencer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="description" className="text-sm font-medium">
              Description *
            </label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              placeholder="Enter product description"
              required
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox id="trending" checked={formData.trending} onCheckedChange={handleCheckboxChange} />
            <label htmlFor="trending" className="text-sm font-medium">
              Mark as trending product
            </label>
          </div>

          <Button type="submit" className="w-full bg-[#6366f1] hover:bg-[#5457e5]" disabled={isLoading}>
            {isLoading ? "Adding Product..." : "Add Product"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
