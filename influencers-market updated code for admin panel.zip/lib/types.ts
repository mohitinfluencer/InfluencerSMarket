export interface Influencer {
  id: string
  name: string
  profileImage: string
  profileUrl: string
  followers: string
}

export interface Product {
  id: string
  name: string
  price: number
  images: string[]
  category: string
  creatorName: string
  creatorId: string
  description: string
  trending?: boolean
  rating: number
  reviews: number
  sizes: string[]
  colors: string[]
  reviewTexts: string[]
}

export interface User {
  id: string
  name: string
  email: string
  mobile: string
  address: string
  pincode: string
  state: string
}

export interface Order {
  id: string
  product: Product
  user: User
  status: "pending" | "confirmed"
  date: string
  productDetails?: {
    size?: string
    color?: string
  }
}

export interface CartItem {
  id: string
  product: Product
  quantity: number
  selectedSize?: string
  selectedColor?: string
}
