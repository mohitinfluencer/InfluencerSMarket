import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Skip middleware for static files and API routes
  if (
    request.nextUrl.pathname.startsWith("/_next") ||
    request.nextUrl.pathname.startsWith("/api") ||
    request.nextUrl.pathname.startsWith("/static")
  ) {
    return NextResponse.next()
  }

  // Allow direct access to admin login page
  if (request.nextUrl.pathname === "/admin/login") {
    return NextResponse.next()
  }

  // Check if trying to access admin pages
  if (request.nextUrl.pathname.startsWith("/admin")) {
    // Get admin cookie
    const adminAuthenticated = request.cookies.get("adminAuthenticated")?.value

    // If not authenticated, redirect to login
    if (adminAuthenticated !== "true") {
      return NextResponse.redirect(new URL("/admin/login", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*"],
}
