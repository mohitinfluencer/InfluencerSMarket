"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { getProductById, indianStates } from "@/lib/data"
import type { Product } from "@/lib/types"

export default function ProductPage() {
  const params = useParams()
  const router = useRouter()
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [selectedSize, setSelectedSize] = useState("")
  const [selectedColor, setSelectedColor] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [showReviews, setShowReviews] = useState(false)
  const [orderForm, setOrderForm] = useState({
    fullName: "",
    address: "",
    mobile: "",
    pincode: "",
    email: "",
    state: "",
  })

  useEffect(() => {
    if (params.id) {
      const productData = getProductById(params.id as string)
      setProduct(productData || null)
      if (productData) {
        setSelectedSize(productData.sizes[0] || "")
        setSelectedColor(productData.colors[0] || "")
      }
      setLoading(false)
    }
  }, [params.id])

  const handleAddToCart = () => {
    if (!product) return

    try {
      const cartItems = JSON.parse(localStorage.getItem("cartItems") || "[]")
      const existingItemIndex = cartItems.findIndex(
        (item: any) =>
          item.product.id === product.id && item.selectedSize === selectedSize && item.selectedColor === selectedColor,
      )

      if (existingItemIndex >= 0) {
        cartItems[existingItemIndex].quantity += quantity
      } else {
        cartItems.push({
          id: `cart_${Date.now()}`,
          product: product,
          quantity: quantity,
          selectedSize,
          selectedColor,
        })
      }

      localStorage.setItem("cartItems", JSON.stringify(cartItems))

      // Trigger storage event to update UI
      window.dispatchEvent(new Event("storage"))

      alert(`${product.name} has been added to your cart`)
    } catch (error) {
      alert("Failed to add item to cart")
    }
  }

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!product) return

    try {
      // Validate required fields
      if (
        !orderForm.fullName ||
        !orderForm.address ||
        !orderForm.mobile ||
        !orderForm.pincode ||
        !orderForm.email ||
        !orderForm.state
      ) {
        alert("Please fill in all required fields")
        return
      }

      const newOrder = {
        id: `ORD${Date.now()}`,
        product: product,
        user: {
          id: "1",
          name: orderForm.fullName,
          email: orderForm.email,
          mobile: orderForm.mobile,
          address: orderForm.address,
          pincode: orderForm.pincode,
          state: orderForm.state,
        },
        status: "pending" as const,
        date: new Date().toISOString(),
        productDetails: {
          size: selectedSize,
          color: selectedColor,
        },
      }

      // Add to user orders
      const userOrders = JSON.parse(localStorage.getItem("userOrders") || "[]")
      userOrders.push(newOrder)
      localStorage.setItem("userOrders", JSON.stringify(userOrders))

      // Add to all orders
      const allOrders = JSON.parse(localStorage.getItem("allOrders") || "[]")
      allOrders.push(newOrder)
      localStorage.setItem("allOrders", JSON.stringify(allOrders))

      // Trigger storage event to update UI
      window.dispatchEvent(new Event("storage"))

      alert("Order placed successfully!")
      setShowOrderForm(false)

      // Reset form
      setOrderForm({
        fullName: "",
        address: "",
        mobile: "",
        pincode: "",
        email: "",
        state: "",
      })

      // Redirect to orders page after a short delay
      setTimeout(() => {
        router.push("/orders")
      }, 1000)
    } catch (error) {
      alert("Failed to place order. Please try again.")
    }
  }

  const increaseQuantity = () => setQuantity((prev) => prev + 1)
  const decreaseQuantity = () => setQuantity((prev) => (prev > 1 ? prev - 1 : 1))

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  if (!product) {
    return <div className="min-h-screen flex items-center justify-center">Product not found</div>
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
              <img
                src={product.images[currentImageIndex] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement
                  target.src = "/placeholder.svg?height=500&width=500"
                }}
              />
              {product.images.length > 1 && (
                <>
                  <button
                    className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-md"
                    onClick={() =>
                      setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length)
                    }
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                  </button>
                  <button
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-md"
                    onClick={() => setCurrentImageIndex((prev) => (prev + 1) % product.images.length)}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </>
              )}
            </div>

            {/* Thumbnail Images */}
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    className={`relative w-20 h-20 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                      index === currentImageIndex ? "border-[#6366f1]" : "border-gray-200"
                    }`}
                    onClick={() => setCurrentImageIndex(index)}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} - view ${index + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement
                        target.src = "/placeholder.svg?height=80&width=80"
                      }}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <p className="text-sm text-gray-500 uppercase tracking-wide mb-2">MY STORE</p>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{product.name}</h1>

              {/* Rating */}
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className={`w-5 h-5 ${star <= Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="text-sm text-gray-600 ml-2">
                  {product.rating} ({product.reviews} reviews)
                </span>
                <button onClick={() => setShowReviews(!showReviews)} className="text-blue-600 text-sm ml-2 underline">
                  {showReviews ? "Hide" : "Show"} Reviews
                </button>
              </div>

              {/* Price */}
              <div className="flex items-center space-x-3 mb-6">
                <span className="text-lg text-gray-500 line-through">Rs. 999.00</span>
                <span className="text-2xl font-bold text-gray-900">Rs. {product.price}.00</span>
                <span className="bg-black text-white px-2 py-1 text-sm rounded">Sale</span>
              </div>

              <p className="text-sm text-gray-600 mb-6">Taxes included.</p>
            </div>

            {/* Size Selection */}
            {product.sizes.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
                <select
                  value={selectedSize}
                  onChange={(e) => setSelectedSize(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#6366f1] focus:border-transparent"
                >
                  {product.sizes.map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Color Selection */}
            {product.colors.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#6366f1] focus:border-transparent"
                >
                  {product.colors.map((color) => (
                    <option key={color} value={color}>
                      {color}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Quantity */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
              <div className="flex items-center border border-gray-300 rounded-md w-32">
                <button onClick={decreaseQuantity} className="p-3 hover:bg-gray-100 transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                  </svg>
                </button>
                <span className="flex-1 text-center py-3 border-x border-gray-300">{quantity}</span>
                <button onClick={increaseQuantity} className="p-3 hover:bg-gray-100 transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleAddToCart}
                className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 py-4 rounded-md font-medium transition-colors"
              >
                Add to cart
              </button>
              <button
                onClick={() => setShowOrderForm(true)}
                className="w-full bg-gray-800 hover:bg-gray-900 text-white py-4 rounded-md font-medium flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v5a2 2 0 11-4 0v-5m4 0V9a2 2 0 10-4 0v4.01"
                  />
                </svg>
                Order Now - Cash on Delivery
              </button>
            </div>

            {/* Product Description */}
            <div className="border-t pt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Product Description</h3>
              <p className="text-gray-700 leading-relaxed">{product.description}</p>

              <div className="mt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Category:</span>
                  <span className="text-sm font-medium capitalize">{product.category.replace("-", " ")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Creator:</span>
                  <span className="text-sm font-medium">{product.creatorName}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        {showReviews && product.reviewTexts && (
          <div className="mt-12 bg-gray-50 rounded-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Customer Reviews</h3>
            <div className="space-y-6">
              {product.reviewTexts.map((review, index) => (
                <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg
                          key={star}
                          className="w-4 h-4 text-yellow-400 fill-yellow-400"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-xs text-gray-500 ml-2">Verified Purchase</span>
                  </div>
                  <p className="text-gray-700">{review}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Order Form Modal */}
        {showOrderForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
              <h3 className="text-lg font-bold mb-4">Complete Your Order</h3>

              <form onSubmit={handleOrderSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={orderForm.fullName}
                    onChange={(e) => setOrderForm({ ...orderForm, fullName: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Address *</label>
                  <input
                    type="text"
                    required
                    value={orderForm.address}
                    onChange={(e) => setOrderForm({ ...orderForm, address: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Mobile *</label>
                  <input
                    type="tel"
                    required
                    value={orderForm.mobile}
                    onChange={(e) => setOrderForm({ ...orderForm, mobile: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Pincode *</label>
                    <input
                      type="text"
                      required
                      value={orderForm.pincode}
                      onChange={(e) => setOrderForm({ ...orderForm, pincode: e.target.value })}
                      className="w-full p-2 border border-gray-300 rounded-md"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">State *</label>
                    <select
                      required
                      value={orderForm.state}
                      onChange={(e) => setOrderForm({ ...orderForm, state: e.target.value })}
                      className="w-full p-2 border border-gray-300 rounded-md"
                    >
                      <option value="">Select State</option>
                      {indianStates.map((state) => (
                        <option key={state} value={state}>
                          {state}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={orderForm.email}
                    onChange={(e) => setOrderForm({ ...orderForm, email: e.target.value })}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  />
                </div>

                <div className="bg-gray-50 p-3 rounded-md">
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full border-2 border-[#6366f1] flex items-center justify-center mr-2">
                      <div className="w-2 h-2 rounded-full bg-[#6366f1]"></div>
                    </div>
                    <span className="font-medium">Cash on Delivery</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 ml-6">Pay when your order arrives</p>
                </div>

                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowOrderForm(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-md"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="flex-1 bg-[#6366f1] text-white py-2 rounded-md">
                    Place Order
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2 z-10">
        <a href="/" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
            />
          </svg>
          <span className="text-xs mt-1">Home</span>
        </a>
        <a href="/search" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <span className="text-xs mt-1">Search</span>
        </a>
        <a href="/orders" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
            />
          </svg>
          <span className="text-xs mt-1">Orders</span>
        </a>
        <a href="/cart" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v5a2 2 0 11-4 0v-5m4 0V9a2 2 0 10-4 0v4.01"
            />
          </svg>
          <span className="text-xs mt-1">Cart</span>
        </a>
        <a href="/profile" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
            />
          </svg>
          <span className="text-xs mt-1">Profile</span>
        </a>
      </nav>

      <div className="pb-16"></div>
    </div>
  )
}
