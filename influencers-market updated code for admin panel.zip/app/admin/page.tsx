import { redirect } from "next/navigation"

export default function AdminIndexPage() {
  // Redirect to analytics by default
  redirect("/admin/analytics")
}
