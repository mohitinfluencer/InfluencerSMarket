"use client"

import { useEffect, useState } from "react"
import type React from "react"
import { AdminBottomNav } from "@/components/admin-bottom-nav"
import { useRouter } from "next/navigation"
import Cookies from "js-cookie"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if admin is authenticated via cookie
    const adminAuthenticated = Cookies.get("adminAuthenticated") === "true"

    // For backward compatibility, also check localStorage
    const localStorageAuth = localStorage.getItem("adminAuthenticated") === "true"

    if (adminAuthenticated || localStorageAuth) {
      // Ensure both are set
      if (adminAuthenticated && !localStorageAuth) {
        localStorage.setItem("adminAuthenticated", "true")
      }
      if (!adminAuthenticated && localStorageAuth) {
        Cookies.set("adminAuthenticated", "true", { expires: 7 })
      }

      setIsAuthenticated(true)
    } else if (window.location.pathname !== "/admin/login") {
      router.push("/admin/login")
    }

    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated && window.location.pathname !== "/admin/login") {
    return null // Don't render anything while redirecting
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-primary text-white p-4">
        <h1 className="text-xl font-bold">InfluencersMarket Admin</h1>
      </header>
      <main className="pb-16">{children}</main>
      <AdminBottomNav />
    </div>
  )
}
