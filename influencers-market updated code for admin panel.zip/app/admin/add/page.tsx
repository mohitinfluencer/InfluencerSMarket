"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getInfluencers, addProduct, addInfluencer } from "@/lib/data"
import type { Influencer } from "@/lib/types"

export default function AdminAddPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"product" | "influencer">("product")
  const [influencers, setInfluencers] = useState<Influencer[]>([])
  const [isLoading, setIsLoading] = useState(false)

  // Product form state
  const [productForm, setProductForm] = useState({
    name: "",
    price: "",
    category: "",
    creatorId: "",
    description: "",
    trending: false,
    sizes: [] as string[],
    colors: [] as string[],
  })
  const [productImages, setProductImages] = useState<string[]>([])
  const [newColor, setNewColor] = useState("")

  // Influencer form state
  const [influencerForm, setInfluencerForm] = useState({
    name: "",
    profileImage: "",
    profileUrl: "",
    followers: "",
  })

  useEffect(() => {
    // Check authentication
    const isAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
    if (!isAuthenticated) {
      router.push("/admin/login")
      return
    }

    setInfluencers(getInfluencers())
  }, [router])

  const sizeOptions = ["S", "M", "L", "XL", "XXL"]

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newImages: string[] = []
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (event) => {
          if (event.target?.result) {
            newImages.push(event.target.result as string)
            if (newImages.length === files.length) {
              setProductImages((prev) => [...prev, ...newImages])
            }
          }
        }
        reader.readAsDataURL(file)
      }
    }
  }

  const handleInfluencerImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          setInfluencerForm({ ...influencerForm, profileImage: event.target.result as string })
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSizeToggle = (size: string) => {
    setProductForm((prev) => {
      if (prev.sizes.includes(size)) {
        return { ...prev, sizes: prev.sizes.filter((s) => s !== size) }
      } else {
        return { ...prev, sizes: [...prev.sizes, size] }
      }
    })
  }

  const handleAddColor = () => {
    if (newColor && !productForm.colors.includes(newColor)) {
      setProductForm((prev) => ({ ...prev, colors: [...prev.colors, newColor] }))
      setNewColor("")
    }
  }

  const handleRemoveColor = (color: string) => {
    setProductForm((prev) => ({ ...prev, colors: prev.colors.filter((c) => c !== color) }))
  }

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (
        !productForm.name ||
        !productForm.price ||
        !productForm.category ||
        !productForm.creatorId ||
        !productForm.description
      ) {
        alert("Please fill in all required fields")
        setIsLoading(false)
        return
      }

      if (productImages.length === 0) {
        alert("Please upload at least one product image")
        setIsLoading(false)
        return
      }

      const creator = influencers.find((inf) => inf.id === productForm.creatorId)
      if (!creator) {
        alert("Selected creator not found")
        setIsLoading(false)
        return
      }

      const newProduct = {
        id: `product_${Date.now()}`,
        name: productForm.name,
        price: Number.parseInt(productForm.price),
        images: productImages,
        category: productForm.category,
        creatorId: productForm.creatorId,
        creatorName: creator.name,
        description: productForm.description,
        trending: productForm.trending,
        rating: 5.0,
        reviews: 0,
        sizes: productForm.sizes,
        colors: productForm.colors,
      }

      addProduct(newProduct)
      alert("Product added successfully!")

      // Reset form
      setProductForm({
        name: "",
        price: "",
        category: "",
        creatorId: "",
        description: "",
        trending: false,
        sizes: [],
        colors: [],
      })
      setProductImages([])
    } catch (error) {
      alert("Failed to add product. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleInfluencerSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!influencerForm.name || !influencerForm.profileUrl || !influencerForm.followers) {
        alert("Please fill in all required fields")
        setIsLoading(false)
        return
      }

      if (!influencerForm.profileUrl.includes("instagram.com")) {
        alert("Please enter a valid Instagram profile URL")
        setIsLoading(false)
        return
      }

      const newInfluencer = {
        id: `influencer_${Date.now()}`,
        name: influencerForm.name,
        profileImage: influencerForm.profileImage || "/placeholder.svg?height=80&width=80",
        profileUrl: influencerForm.profileUrl,
        followers: influencerForm.followers,
      }

      addInfluencer(newInfluencer)
      alert("Influencer added successfully!")

      // Reset form
      setInfluencerForm({
        name: "",
        profileImage: "",
        profileUrl: "",
        followers: "",
      })
    } catch (error) {
      alert("Failed to add influencer. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#6366f1] text-white p-4">
        <h1 className="text-xl font-bold">InfluencersMarket Admin</h1>
      </header>

      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Add New</h1>

        {/* Tabs */}
        <div className="flex border-b mb-6">
          <button
            onClick={() => setActiveTab("product")}
            className={`px-4 py-2 font-medium ${
              activeTab === "product" ? "border-b-2 border-[#6366f1] text-[#6366f1]" : "text-gray-500"
            }`}
          >
            Add Product
          </button>
          <button
            onClick={() => setActiveTab("influencer")}
            className={`px-4 py-2 font-medium ${
              activeTab === "influencer" ? "border-b-2 border-[#6366f1] text-[#6366f1]" : "text-gray-500"
            }`}
          >
            Add Influencer
          </button>
        </div>

        {/* Product Form */}
        {activeTab === "product" && (
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-bold mb-4">Add New Product</h2>

            <form onSubmit={handleProductSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="Enter product name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Price (₹) *</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={productForm.price}
                  onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="Enter price"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Product Images * (Multiple)</label>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg"
                  multiple
                  onChange={handleImageUpload}
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
                {productImages.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {productImages.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image || "/placeholder.svg"}
                          alt={`Preview ${index + 1}`}
                          className="w-20 h-20 object-cover rounded"
                        />
                        <button
                          type="button"
                          onClick={() => setProductImages(productImages.filter((_, i) => i !== index))}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 text-xs"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Category *</label>
                <select
                  required
                  value={productForm.category}
                  onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="">Select category</option>
                  <option value="fashion">Fashion</option>
                  <option value="beauty">Beauty</option>
                  <option value="other">Other Tools</option>
                </select>
              </div>

              {/* Fashion-specific options */}
              {productForm.category === "fashion" && (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-2">Available Sizes</label>
                    <div className="flex flex-wrap gap-2">
                      {sizeOptions.map((size) => (
                        <label key={size} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={productForm.sizes.includes(size)}
                            onChange={() => handleSizeToggle(size)}
                            className="mr-2"
                          />
                          {size}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Available Colors</label>
                    <div className="flex items-center space-x-2 mb-2">
                      <input
                        type="text"
                        value={newColor}
                        onChange={(e) => setNewColor(e.target.value)}
                        placeholder="Enter color name"
                        className="flex-1 p-2 border border-gray-300 rounded-md"
                      />
                      <button
                        type="button"
                        onClick={handleAddColor}
                        className="px-4 py-2 bg-[#6366f1] text-white rounded-md"
                      >
                        Add
                      </button>
                    </div>
                    {productForm.colors.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {productForm.colors.map((color) => (
                          <div key={color} className="bg-gray-100 px-3 py-1 rounded-full flex items-center">
                            <span className="text-sm">{color}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveColor(color)}
                              className="ml-2 text-red-500"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium mb-1">Creator *</label>
                <select
                  required
                  value={productForm.creatorId}
                  onChange={(e) => setProductForm({ ...productForm, creatorId: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="">Select creator</option>
                  {influencers.map((influencer) => (
                    <option key={influencer.id} value={influencer.id}>
                      {influencer.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Description *</label>
                <textarea
                  required
                  rows={3}
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="Enter product description"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="trending"
                  checked={productForm.trending}
                  onChange={(e) => setProductForm({ ...productForm, trending: e.target.checked })}
                  className="mr-2"
                />
                <label htmlFor="trending" className="text-sm font-medium">
                  Mark as trending product
                </label>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#6366f1] hover:bg-[#5457e5] text-white py-2 rounded-md disabled:opacity-50"
              >
                {isLoading ? "Adding Product..." : "Add Product"}
              </button>
            </form>
          </div>
        )}

        {/* Influencer Form */}
        {activeTab === "influencer" && (
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-bold mb-4">Add New Influencer</h2>

            <form onSubmit={handleInfluencerSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Influencer Name *</label>
                <input
                  type="text"
                  required
                  value={influencerForm.name}
                  onChange={(e) => setInfluencerForm({ ...influencerForm, name: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="Enter influencer name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Profile Image</label>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg"
                  onChange={handleInfluencerImageUpload}
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
                {influencerForm.profileImage && (
                  <div className="mt-2">
                    <img
                      src={influencerForm.profileImage || "/placeholder.svg"}
                      alt="Preview"
                      className="w-20 h-20 object-cover rounded-full"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Instagram Profile URL *</label>
                <input
                  type="url"
                  required
                  value={influencerForm.profileUrl}
                  onChange={(e) => setInfluencerForm({ ...influencerForm, profileUrl: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="https://instagram.com/username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Followers Count *</label>
                <input
                  type="text"
                  required
                  value={influencerForm.followers}
                  onChange={(e) => setInfluencerForm({ ...influencerForm, followers: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  placeholder="e.g., 1.2M, 850K, 2.1M"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#6366f1] hover:bg-[#5457e5] text-white py-2 rounded-md disabled:opacity-50"
              >
                {isLoading ? "Adding Influencer..." : "Add Influencer"}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2 z-10">
        <a href="/admin/users" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
            />
          </svg>
          <span className="text-xs mt-1">Users</span>
        </a>

        <a href="/admin/orders" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
            />
          </svg>
          <span className="text-xs mt-1">Orders</span>
        </a>

        <a href="/admin/search" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <span className="text-xs mt-1">Search</span>
        </a>

        <a href="/admin/add" className="flex flex-col items-center p-2 text-[#6366f1]">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          <span className="text-xs mt-1">Add</span>
        </a>
      </nav>

      <div className="pb-16"></div>
    </div>
  )
}
