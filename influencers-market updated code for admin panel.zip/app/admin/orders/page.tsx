"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { AdminOrdersList } from "@/components/admin/orders-list"

export default function AdminOrdersPage() {
  const router = useRouter()

  useEffect(() => {
    // Check if admin is authenticated
    const isAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
    if (!isAuthenticated) {
      router.push("/admin/login")
    }
  }, [router])

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Orders Management</h1>
      <AdminOrdersList />
    </div>
  )
}
