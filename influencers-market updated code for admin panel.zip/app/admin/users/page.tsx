"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { UsersList } from "@/components/admin/users-list"

export default function AdminUsersPage() {
  const router = useRouter()

  useEffect(() => {
    // Check if admin is authenticated
    const isAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
    if (!isAuthenticated) {
      router.push("/admin/login")
    }
  }, [router])

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Users Management</h1>
      <UsersList />
    </div>
  )
}
