"use client"

import { useState } from "react"
import { UserBottomNav } from "@/components/user-bottom-nav"
import { Input } from "@/components/ui/input"
import { SearchResults } from "@/components/search-results"
import { Search } from "lucide-react"

export default function SearchPage() {
  const [query, setQuery] = useState("")

  return (
    <main className="pb-16">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Search</h1>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input
            type="text"
            placeholder="Search products or influencers..."
            className="pl-10"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>

        <SearchResults query={query} />
      </div>
      <UserBottomNav />
    </main>
  )
}
