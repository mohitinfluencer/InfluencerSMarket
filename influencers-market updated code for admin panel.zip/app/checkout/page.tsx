"use client"

import type React from "react"
import { useState } from "react"
import { UserBottomNav } from "@/components/user-bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getCartItems } from "@/lib/data"
import { toast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function CheckoutPage() {
  const router = useRouter()
  const cartItems = getCartItems()
  const [formData, setFormData] = useState({
    fullName: "",
    address: "",
    mobile: "",
    pincode: "",
    email: "",
    state: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you'd submit this to your backend
    toast({
      title: "Order placed successfully",
      description: "Your order has been placed and will be processed soon",
    })
    router.push("/orders")
  }

  if (cartItems.length === 0) {
    return (
      <main className="pb-16">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center py-10">
            <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
            <p className="text-gray-500 mb-6">Add some products to your cart to checkout</p>
            <Button onClick={() => router.push("/")}>Continue Shopping</Button>
          </div>
        </div>
        <UserBottomNav />
      </main>
    )
  }

  return (
    <main className="pb-16">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>

        {/* Order Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center">
                  <div className="relative w-12 h-12 rounded overflow-hidden">
                    <Image
                      src={item.product.image || "/placeholder.svg"}
                      alt={item.product.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="ml-4 flex-1">
                    <h3 className="font-medium text-sm">{item.product.name}</h3>
                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-bold">₹{item.product.price * item.quantity}</p>
                </div>
              ))}
              <div className="border-t pt-4">
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>₹{calculateTotal()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Shipping Information */}
        <Card>
          <CardHeader>
            <CardTitle>Shipping Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="fullName" className="text-sm font-medium">
                  Full Name
                </label>
                <Input id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <label htmlFor="address" className="text-sm font-medium">
                  Address
                </label>
                <Input id="address" name="address" value={formData.address} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <label htmlFor="mobile" className="text-sm font-medium">
                  Mobile
                </label>
                <Input id="mobile" name="mobile" value={formData.mobile} onChange={handleChange} required />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="pincode" className="text-sm font-medium">
                    Pincode
                  </label>
                  <Input id="pincode" name="pincode" value={formData.pincode} onChange={handleChange} required />
                </div>

                <div className="space-y-2">
                  <label htmlFor="state" className="text-sm font-medium">
                    State
                  </label>
                  <Input id="state" name="state" value={formData.state} onChange={handleChange} required />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg mb-4">
                <div className="flex items-center">
                  <div className="w-6 h-6 rounded-full border-2 border-primary flex items-center justify-center">
                    <div className="w-3 h-3 rounded-full bg-primary"></div>
                  </div>
                  <span className="ml-2 font-medium">Cash on Delivery</span>
                </div>
                <p className="text-sm text-gray-500 mt-1 ml-8">Pay when your order arrives</p>
              </div>

              <Button type="submit" className="w-full">
                Place Order - ₹{calculateTotal()}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
      <UserBottomNav />
    </main>
  )
}
