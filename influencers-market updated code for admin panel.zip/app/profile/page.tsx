import { UserBottomNav } from "@/components/user-bottom-nav"
import { UserProfile } from "@/components/user-profile"

export default function ProfilePage() {
  return (
    <main className="pb-16">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">My Profile</h1>
        <UserProfile />
      </div>
      <UserBottomNav />
    </main>
  )
}
