import type { Influencer, Product, User, Order, CartItem } from "./types"
import { generateFakeReviews } from "./gemini"

// Initialize data in localStorage if not exists
const initializeData = () => {
  if (typeof window === "undefined") return

  // Default influencers
  const defaultInfluencers: Influencer[] = [
    {
      id: "1",
      name: "monsoonkart",
      profileImage:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-06-12%20004759-DfaUmlVxQxDfRK5yk70Vt4949iOdx6.png",
      profileUrl: "https://instagram.com/monsoon_kart",
      followers: "850K",
    },
  ]

  // Default products with proper image URLs and realistic ratings
  const defaultProducts: Product[] = [
    {
      id: "1",
      name: "Everyminutes Wine Bottle Umbrella",
      price: 599,
      images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yU9PiVp7R248I7WhelHnTs53VveWWR.png"],
      category: "other",
      creatorName: "monsoonkart",
      creatorId: "1",
      description:
        "Compact wine bottle shaped umbrella perfect for rainy days. Stylish and functional design that fits easily in your bag.",
      trending: true,
      rating: 4.2,
      reviews: 128,
      sizes: [],
      colors: ["Red", "White", "Black"],
      reviewTexts: [
        "Good quality umbrella, love the unique design. Works well in light rain.",
        "Compact and fits in my bag easily. The wine bottle shape is a nice touch.",
        "Decent umbrella but takes some getting used to. Overall satisfied with purchase.",
        "Great conversation starter! Quality is good for the price.",
        "Works as expected. The opening mechanism could be smoother but it's functional.",
      ],
    },
    {
      id: "2",
      name: "Designer Denim Jacket",
      price: 4999,
      images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yU9PiVp7R248I7WhelHnTs53VveWWR.png"],
      category: "fashion",
      creatorName: "monsoonkart",
      creatorId: "1",
      description: "Stylish denim jacket perfect for casual outings.",
      trending: true,
      rating: 4.6,
      reviews: 87,
      sizes: ["S", "M", "L", "XL"],
      colors: ["Blue", "Black", "White"],
      reviewTexts: [
        "Nice jacket, fits well. The material feels good quality.",
        "Love the style, goes with most of my outfits. Delivery was quick.",
        "Good denim jacket for the price. Comfortable to wear.",
        "Exactly as shown in pictures. Happy with the purchase.",
        "Quality is decent but runs slightly small. Consider sizing up.",
      ],
    },
    {
      id: "3",
      name: "Natural Skincare Set",
      price: 1999,
      images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yU9PiVp7R248I7WhelHnTs53VveWWR.png"],
      category: "beauty",
      creatorName: "monsoonkart",
      creatorId: "1",
      description: "Complete skincare routine with natural ingredients.",
      trending: true,
      rating: 4.4,
      reviews: 215,
      sizes: [],
      colors: [],
      reviewTexts: [
        "Good skincare set, noticed some improvement after regular use.",
        "Natural ingredients work well for my sensitive skin. No irritation.",
        "Complete set with everything needed. Good value for money.",
        "Products smell nice and feel gentle on skin. Will repurchase.",
        "Decent skincare routine. Takes time to see results but worth it.",
      ],
    },
    {
      id: "4",
      name: "Smart Fitness Watch",
      price: 3499,
      images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yU9PiVp7R248I7WhelHnTs53VveWWR.png"],
      category: "other",
      creatorName: "monsoonkart",
      creatorId: "1",
      description: "Track your fitness goals with this advanced smartwatch.",
      trending: true,
      rating: 4.3,
      reviews: 156,
      sizes: [],
      colors: [],
      reviewTexts: [
        "Good fitness tracking features. Battery lasts about 2 days with regular use.",
        "Easy to use and accurate step counting. The app could be better though.",
        "Decent smartwatch for the price. Build quality is satisfactory.",
        "Works well for basic fitness tracking. Some features are limited.",
        "Good value compared to expensive brands. Does what it promises.",
      ],
    },
  ]

  // Initialize if not exists
  if (!localStorage.getItem("influencers")) {
    localStorage.setItem("influencers", JSON.stringify(defaultInfluencers))
  }
  if (!localStorage.getItem("products")) {
    localStorage.setItem("products", JSON.stringify(defaultProducts))
  }
  if (!localStorage.getItem("userOrders")) {
    localStorage.setItem("userOrders", JSON.stringify([]))
  }
  if (!localStorage.getItem("allOrders")) {
    localStorage.setItem("allOrders", JSON.stringify([]))
  }
  if (!localStorage.getItem("cartItems")) {
    localStorage.setItem("cartItems", JSON.stringify([]))
  }
}

// Call initialization
if (typeof window !== "undefined") {
  initializeData()
}

// Indian states for dropdown
export const indianStates = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
  "Lakshadweep",
  "Puducherry",
]

// Data access functions
export function getInfluencers(): Influencer[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem("influencers")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("Error loading influencers:", error)
    return []
  }
}

export function getInfluencerById(id: string): Influencer | undefined {
  return getInfluencers().find((influencer) => influencer.id === id)
}

export function getProducts(): Product[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem("products")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("Error loading products:", error)
    return []
  }
}

export function getTrendingProducts(): Product[] {
  return getProducts()
    .filter((product) => product.trending === true)
    .slice(0, 8)
}

export function getProductsByInfluencer(influencerId: string): Product[] {
  return getProducts().filter((product) => product.creatorId === influencerId)
}

export function getProductById(id: string): Product | undefined {
  return getProducts().find((product) => product.id === id)
}

export function searchProducts(query: string): Product[] {
  return getProducts().filter(
    (product) =>
      product.name.toLowerCase().includes(query.toLowerCase()) ||
      product.creatorName.toLowerCase().includes(query.toLowerCase()),
  )
}

export function searchInfluencers(query: string): Influencer[] {
  return getInfluencers().filter((influencer) => influencer.name.toLowerCase().includes(query.toLowerCase()))
}

export function getUserOrders(): Order[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem("userOrders")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("Error loading user orders:", error)
    return []
  }
}

export function getAllOrders(): Order[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem("allOrders")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("Error loading all orders:", error)
    return []
  }
}

export function getCartItems(): CartItem[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem("cartItems")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("Error loading cart items:", error)
    return []
  }
}

// Add functions
export async function addProduct(product: Omit<Product, "reviewTexts">): Promise<void> {
  if (typeof window === "undefined") return
  try {
    // Generate fake reviews using Gemini API
    const reviewTexts = await generateFakeReviews(product.name, product.category)

    // Generate realistic rating between 4.0 and 5.0
    const rating = Math.round((4.0 + Math.random() * 1.0) * 10) / 10

    const productWithReviews: Product = {
      ...product,
      reviewTexts,
      reviews: reviewTexts.length,
      rating: rating,
    }

    const products = getProducts()
    products.push(productWithReviews)
    localStorage.setItem("products", JSON.stringify(products))

    // Trigger storage event to update UI
    window.dispatchEvent(new Event("storage"))
  } catch (error) {
    console.error("Error adding product:", error)
    throw error
  }
}

export function addInfluencer(influencer: Influencer): void {
  if (typeof window === "undefined") return
  try {
    const influencers = getInfluencers()
    influencers.push(influencer)
    localStorage.setItem("influencers", JSON.stringify(influencers))
  } catch (error) {
    console.error("Error adding influencer:", error)
    throw error
  }
}

export function addOrder(orderData: {
  productId: string
  userInfo: {
    fullName: string
    address: string
    mobile: string
    pincode: string
    email: string
    state: string
  }
  productDetails?: {
    size?: string
    color?: string
  }
}): void {
  if (typeof window === "undefined") return

  const product = getProductById(orderData.productId)
  if (!product) return

  const newOrder: Order = {
    id: `ORD${Date.now()}`,
    product: product,
    user: {
      id: "1",
      name: orderData.userInfo.fullName,
      email: orderData.userInfo.email,
      mobile: orderData.userInfo.mobile,
      address: orderData.userInfo.address,
      pincode: orderData.userInfo.pincode,
      state: orderData.userInfo.state,
    },
    status: "pending",
    date: new Date().toISOString(),
    productDetails: orderData.productDetails,
  }

  try {
    // Add to user orders
    const userOrders = getUserOrders()
    userOrders.push(newOrder)
    localStorage.setItem("userOrders", JSON.stringify(userOrders))

    // Add to all orders
    const allOrders = getAllOrders()
    allOrders.push(newOrder)
    localStorage.setItem("allOrders", JSON.stringify(allOrders))
  } catch (error) {
    console.error("Error saving order:", error)
    throw error
  }
}

export function updateOrderStatus(orderId: string, status: "pending" | "confirmed"): void {
  if (typeof window === "undefined") return

  try {
    // Update user orders
    const userOrders = getUserOrders()
    const updatedUserOrders = userOrders.map((order) => (order.id === orderId ? { ...order, status } : order))
    localStorage.setItem("userOrders", JSON.stringify(updatedUserOrders))

    // Update all orders
    const allOrders = getAllOrders()
    const updatedAllOrders = allOrders.map((order) => (order.id === orderId ? { ...order, status } : order))
    localStorage.setItem("allOrders", JSON.stringify(updatedAllOrders))
  } catch (error) {
    console.error("Error updating order status:", error)
    throw error
  }
}

// Delete functions
export function deleteProduct(productId: string): void {
  if (typeof window === "undefined") return
  try {
    const products = getProducts().filter((product) => product.id !== productId)
    localStorage.setItem("products", JSON.stringify(products))
  } catch (error) {
    console.error("Error deleting product:", error)
    throw error
  }
}

export function deleteInfluencer(influencerId: string): void {
  if (typeof window === "undefined") return
  try {
    const influencers = getInfluencers().filter((influencer) => influencer.id !== influencerId)
    localStorage.setItem("influencers", JSON.stringify(influencers))
  } catch (error) {
    console.error("Error deleting influencer:", error)
    throw error
  }
}

// Update functions
export function updateProduct(productId: string, updatedProduct: Product): void {
  if (typeof window === "undefined") return
  try {
    const products = getProducts().map((product) => (product.id === productId ? updatedProduct : product))
    localStorage.setItem("products", JSON.stringify(products))
  } catch (error) {
    console.error("Error updating product:", error)
    throw error
  }
}

export function updateInfluencer(influencerId: string, updatedInfluencer: Influencer): void {
  if (typeof window === "undefined") return
  try {
    const influencers = getInfluencers().map((influencer) =>
      influencer.id === influencerId ? updatedInfluencer : influencer,
    )
    localStorage.setItem("influencers", JSON.stringify(influencers))
  } catch (error) {
    console.error("Error updating influencer:", error)
    throw error
  }
}

// Dashboard analytics functions
export function getDashboardStats() {
  const orders = getAllOrders()
  const products = getProducts()
  const influencers = getInfluencers()

  const today = new Date()
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate())

  // Calculate total sales
  const totalSales = orders.reduce((sum, order) => sum + order.product.price, 0)

  // Calculate today's sales
  const todaysSales = orders
    .filter((order) => new Date(order.date) >= todayStart)
    .reduce((sum, order) => sum + order.product.price, 0)

  // Calculate products sold
  const productsSold = orders.length

  // Calculate today's orders
  const todaysOrders = orders.filter((order) => new Date(order.date) >= todayStart).length

  return {
    totalSales,
    todaysSales,
    productsSold,
    todaysOrders,
    totalProducts: products.length,
    totalInfluencers: influencers.length,
  }
}

// Mock user data
export function getUserProfile(): User {
  return {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    mobile: "9876543210",
    address: "123 Main Street, Mumbai",
    pincode: "400001",
    state: "Maharashtra",
  }
}

export function getAllUsers(): User[] {
  return [getUserProfile()]
}
