export async function generateFakeReviews(productName: string, productCategory: string): Promise<string[]> {
  const API_KEY = "AIzaSyAI7kPYxjEXOs1I5vC7CJMZP1Zqymy1nkk"

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Generate 5 realistic customer reviews for a ${productCategory} product called "${productName}". Make them sound natural and authentic, with a mix of positive feedback and minor constructive criticism. Each review should be 1-2 sentences. Include realistic concerns customers might have. Return only the reviews separated by newlines, no numbering or extra formatting.`,
                },
              ],
            },
          ],
        }),
      },
    )

    const data = await response.json()
    const reviewText = data.candidates?.[0]?.content?.parts?.[0]?.text || ""

    if (reviewText) {
      return reviewText
        .split("\n")
        .filter((review) => review.trim().length > 0)
        .slice(0, 5)
    }
  } catch (error) {
    console.error("Error generating reviews:", error)
  }

  // Fallback realistic reviews if API fails
  const fallbackReviews = [
    "Good quality product, works as expected. Delivery was on time.",
    "Decent purchase for the price. Could be better but satisfied overall.",
    "Nice product, exactly as described. Would recommend to others.",
    "Good value for money. Some minor issues but nothing major.",
    "Happy with the purchase. Quality is good and shipping was fast.",
  ]

  return fallbackReviews
}
