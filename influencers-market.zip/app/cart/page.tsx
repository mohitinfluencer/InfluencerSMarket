import { UserBottomNav } from "@/components/user-bottom-nav"
import { CartItems } from "@/components/cart-items"

export default function CartPage() {
  return (
    <main className="pb-16">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">My Cart</h1>
        <CartItems />
      </div>
      <UserBottomNav />
    </main>
  )
}
