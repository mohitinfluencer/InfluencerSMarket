"use client"

import { useState } from "react"
import { UserBottomNav } from "@/components/user-bottom-nav"
import { ProductGrid } from "@/components/product-grid"
import { InfluencerHeader } from "@/components/influencer-header"
import { CategoryTabs } from "@/components/category-tabs"
import { getInfluencerById } from "@/lib/data"
import { notFound } from "next/navigation"

interface InfluencerPageProps {
  params: {
    id: string
  }
}

export default function InfluencerPage({ params }: InfluencerPageProps) {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const influencer = getInfluencerById(params.id)

  if (!influencer) {
    return notFound()
  }

  return (
    <main className="pb-16">
      <div className="container mx-auto px-4 py-6">
        <InfluencerHeader influencer={influencer} />
        <CategoryTabs onCategoryChange={setSelectedCategory} />
        <ProductGrid influencerId={params.id} selectedCategory={selectedCategory} />
      </div>
      <UserBottomNav />
    </main>
  )
}
