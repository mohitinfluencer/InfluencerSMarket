import type React from "react"
import { AdminBottomNav } from "@/components/admin-bottom-nav"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-primary text-white p-4">
        <h1 className="text-xl font-bold">InfluencersMarket Admin</h1>
      </header>
      <main className="pb-16">{children}</main>
      <AdminBottomNav />
    </div>
  )
}
