"use client"

import { useState, useEffect } from "react"
import type { Order } from "@/lib/types"

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadOrders = () => {
      try {
        const stored = localStorage.getItem("userOrders")
        const ordersData = stored ? JSON.parse(stored) : []
        setOrders(ordersData)
      } catch (error) {
        console.error("Error loading orders:", error)
      } finally {
        setLoading(false)
      }
    }

    loadOrders()

    // Listen for storage changes to refresh orders
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "userOrders" || e.key === null) {
        loadOrders()
      }
    }

    const handleCustomStorageChange = () => {
      loadOrders()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("storage", handleCustomStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("storage", handleCustomStorageChange)
    }
  }, [])

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">My Orders</h1>

        {orders.length === 0 ? (
          <div className="text-center py-10 text-gray-500">You haven't placed any orders yet</div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex items-center">
                  <div className="w-16 h-16 rounded overflow-hidden">
                    <img
                      src={order.product.images[0] || "/placeholder.svg"}
                      alt={order.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium">{order.product.name}</h3>
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          order.status === "pending" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"
                        }`}
                      >
                        {order.status === "pending" ? "Pending" : "Confirmed"}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">Order #{order.id}</p>
                    <p className="text-sm font-bold mt-1">₹{order.product.price}</p>
                    <p className="text-xs text-gray-500 mt-1">Ordered on {new Date(order.date).toLocaleDateString()}</p>

                    {order.productDetails && (
                      <div className="mt-2 text-xs">
                        {order.productDetails.size && <span className="mr-3">Size: {order.productDetails.size}</span>}
                        {order.productDetails.color && <span>Color: {order.productDetails.color}</span>}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2 z-10">
        <a href="/" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
            />
          </svg>
          <span className="text-xs mt-1">Home</span>
        </a>
        <a href="/search" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <span className="text-xs mt-1">Search</span>
        </a>
        <a href="/orders" className="flex flex-col items-center p-2 text-[#6366f1]">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
            />
          </svg>
          <span className="text-xs mt-1">Orders</span>
        </a>
        <a href="/cart" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v5a2 2 0 11-4 0v-5m4 0V9a2 2 0 10-4 0v4.01"
            />
          </svg>
          <span className="text-xs mt-1">Cart</span>
        </a>
        <a href="/profile" className="flex flex-col items-center p-2 text-gray-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
            />
          </svg>
          <span className="text-xs mt-1">Profile</span>
        </a>
      </nav>
    </div>
  )
}
