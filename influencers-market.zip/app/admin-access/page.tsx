"use client"

import { useState, useEffect } from "react"
import { getProducts, getInfluencers, deleteProduct, deleteInfluencer } from "@/lib/data"
import type { Product, Influencer } from "@/lib/types"

export default function AdminAccessPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [influencers, setInfluencers] = useState<Influencer[]>([])
  const [activeTab, setActiveTab] = useState<"products" | "influencers">("products")

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    setProducts(getProducts())
    setInfluencers(getInfluencers())
  }

  const handleDeleteProduct = (productId: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      deleteProduct(productId)
      loadData()
      alert("Product deleted successfully!")
    }
  }

  const handleDeleteInfluencer = (influencerId: string) => {
    if (confirm("Are you sure you want to delete this influencer?")) {
      deleteInfluencer(influencerId)
      loadData()
      alert("Influencer deleted successfully!")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Admin Panel Access</h1>
            <p className="text-xl text-gray-600">Manage your InfluencersMarket platform</p>
          </div>

          {/* Admin Credentials */}
          <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                />
              </svg>
              Admin Credentials
            </h2>
            <div className="bg-gray-100 p-4 rounded-lg">
              <p className="font-medium mb-2">Email: monsoonkart7738@gmail.com</p>
              <p className="font-medium">Password: python.org7738</p>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-3 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"
                  />
                </svg>
                User Management
              </h3>
              <p className="text-gray-600 mb-4">View and manage all registered users, their details, and activity.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• View user profiles</li>
                <li>• Search users by name/email</li>
                <li>• Monitor user activity</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-3 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                  />
                </svg>
                Order Management
              </h3>
              <p className="text-gray-600 mb-4">Track and update order status, manage customer orders.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• View all orders</li>
                <li>• Update order status</li>
                <li>• Mark orders as confirmed</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-3 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                Search & Analytics
              </h3>
              <p className="text-gray-600 mb-4">Search products and influencers, view platform analytics.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Search products</li>
                <li>• Find influencers</li>
                <li>• Delete items</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-3 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
                Content Management
              </h3>
              <p className="text-gray-600 mb-4">Add new products and influencers to the platform.</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Add new products</li>
                <li>• Add new influencers</li>
                <li>• Manage categories</li>
              </ul>
            </div>
          </div>

          {/* Admin Panel Access Button */}
          <div className="text-center mb-8">
            <a
              href="/admin/login"
              className="inline-block bg-[#6366f1] hover:bg-[#5457e5] text-white px-8 py-3 rounded-lg font-medium transition-colors"
            >
              Access Admin Panel
            </a>
          </div>

          {/* Delete and Edit Section */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-xl font-bold mb-6">Manage Products & Influencers</h2>

            {/* Tabs */}
            <div className="flex border-b mb-6">
              <button
                onClick={() => setActiveTab("products")}
                className={`px-4 py-2 font-medium ${
                  activeTab === "products" ? "border-b-2 border-[#6366f1] text-[#6366f1]" : "text-gray-500"
                }`}
              >
                Products ({products.length})
              </button>
              <button
                onClick={() => setActiveTab("influencers")}
                className={`px-4 py-2 font-medium ${
                  activeTab === "influencers" ? "border-b-2 border-[#6366f1] text-[#6366f1]" : "text-gray-500"
                }`}
              >
                Influencers ({influencers.length})
              </button>
            </div>

            {/* Products Tab */}
            {activeTab === "products" && (
              <div className="space-y-4">
                {products.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No products found</p>
                ) : (
                  products.map((product) => (
                    <div key={product.id} className="border rounded-lg p-4">
                      <div className="flex items-center">
                        <div className="w-16 h-16 rounded overflow-hidden">
                          <img
                            src={product.images[0] || "/placeholder.svg"}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="ml-4 flex-1">
                          <h3 className="font-medium">{product.name}</h3>
                          <p className="text-sm text-gray-500">{product.creatorName}</p>
                          <p className="text-sm font-bold">₹{product.price}</p>
                          <p className="text-xs text-gray-500">Category: {product.category}</p>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleDeleteProduct(product.id)}
                            className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Influencers Tab */}
            {activeTab === "influencers" && (
              <div className="space-y-4">
                {influencers.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No influencers found</p>
                ) : (
                  influencers.map((influencer) => (
                    <div key={influencer.id} className="border rounded-lg p-4">
                      <div className="flex items-center">
                        <div className="w-16 h-16 rounded-full overflow-hidden">
                          <img
                            src={influencer.profileImage || "/placeholder.svg"}
                            alt={influencer.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="ml-4 flex-1">
                          <h3 className="font-medium">{influencer.name}</h3>
                          <p className="text-sm text-gray-500">{influencer.followers} followers</p>
                          <p className="text-xs text-gray-500">Profile: {influencer.profileUrl}</p>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleDeleteInfluencer(influencer.id)}
                            className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
