"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import { addInfluencer } from "@/lib/data"
import { Upload } from "lucide-react"

export function AddInfluencerForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [imagePreview, setImagePreview] = useState<string>("")
  const [formData, setFormData] = useState({
    name: "",
    profileImage: "",
    profileUrl: "",
    followers: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Validate file type
      const validTypes = ["image/png", "image/jpg", "image/jpeg"]
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please select a PNG or JPG image file",
          variant: "destructive",
        })
        return
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select an image smaller than 5MB",
          variant: "destructive",
        })
        return
      }

      // Create preview
      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        setImagePreview(result)
        setFormData((prev) => ({ ...prev, profileImage: result }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validate form data
      if (!formData.name || !formData.profileUrl || !formData.followers) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Validate Instagram URL
      if (!formData.profileUrl.includes("instagram.com")) {
        toast({
          title: "Invalid URL",
          description: "Please enter a valid Instagram profile URL",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Create influencer object
      const newInfluencer = {
        id: `influencer_${Date.now()}`,
        name: formData.name,
        profileImage: formData.profileImage || "/placeholder.svg?height=80&width=80",
        profileUrl: formData.profileUrl,
        followers: formData.followers,
      }

      // Add influencer to data store
      addInfluencer(newInfluencer)

      toast({
        title: "Success!",
        description: "Influencer has been added successfully",
      })

      // Reset form
      setFormData({
        name: "",
        profileImage: "",
        profileUrl: "",
        followers: "",
      })
      setImagePreview("")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add influencer. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Influencer</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="name" className="text-sm font-medium">
              Influencer Name *
            </label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter influencer name"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="profileImage" className="text-sm font-medium">
              Profile Image
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
              <input
                id="profileImage"
                type="file"
                accept=".png,.jpg,.jpeg"
                onChange={handleImageUpload}
                className="hidden"
              />
              <label
                htmlFor="profileImage"
                className="flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 p-4 rounded"
              >
                {imagePreview ? (
                  <div className="w-20 h-20 relative">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Preview"
                      className="w-full h-full object-cover rounded-full"
                    />
                  </div>
                ) : (
                  <>
                    <Upload className="w-12 h-12 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-600">Click to upload profile image</p>
                    <p className="text-xs text-gray-400">PNG, JPG up to 5MB</p>
                  </>
                )}
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="profileUrl" className="text-sm font-medium">
              Instagram Profile URL *
            </label>
            <Input
              id="profileUrl"
              name="profileUrl"
              type="url"
              value={formData.profileUrl}
              onChange={handleChange}
              placeholder="https://instagram.com/username"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="followers" className="text-sm font-medium">
              Followers Count *
            </label>
            <Input
              id="followers"
              name="followers"
              value={formData.followers}
              onChange={handleChange}
              placeholder="e.g., 1.2M, 850K, 2.1M"
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Adding Influencer..." : "Add Influencer"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
