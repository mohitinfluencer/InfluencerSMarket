"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { CartItem } from "@/lib/types"
import { Trash2, Plus, Minus } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function CartItems() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])

  useEffect(() => {
    const loadCartItems = () => {
      try {
        const items = JSON.parse(localStorage.getItem("cartItems") || "[]")
        setCartItems(items)
      } catch (error) {
        console.error("Error loading cart items:", error)
      }
    }

    loadCartItems()

    // Listen for storage changes to refresh cart
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "cartItems" || e.key === null) {
        loadCartItems()
      }
    }

    const handleCustomStorageChange = () => {
      loadCartItems()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("storage", handleCustomStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("storage", handleCustomStorageChange)
    }
  }, [])

  const updateCartInStorage = (items: CartItem[]) => {
    localStorage.setItem("cartItems", JSON.stringify(items))
    setCartItems(items)
    // Trigger storage event
    window.dispatchEvent(new Event("storage"))
  }

  const removeFromCart = (id: string) => {
    const updatedItems = cartItems.filter((item) => item.id !== id)
    updateCartInStorage(updatedItems)
    toast({
      title: "Item removed",
      description: "Item has been removed from your cart",
    })
  }

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(id)
      return
    }

    const updatedItems = cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item))
    updateCartInStorage(updatedItems)
  }

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0)
  }

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-10">
        <div className="text-gray-500 mb-4">Your cart is empty</div>
        <Link href="/">
          <Button>Continue Shopping</Button>
        </Link>
      </div>
    )
  }

  return (
    <div>
      <div className="space-y-4 mb-6">
        {cartItems.map((item) => (
          <Card key={item.id}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="relative w-16 h-16 rounded overflow-hidden">
                  <Image
                    src={item.product.images[0] || "/placeholder.svg"}
                    alt={item.product.name}
                    fill
                    className="object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = "/placeholder.svg?height=64&width=64"
                    }}
                  />
                </div>
                <div className="ml-4 flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium">{item.product.name}</h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-red-500"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">{item.product.creatorName}</p>
                  <div className="flex justify-between items-center mt-2">
                    <p className="font-bold">₹{item.product.price}</p>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus size={14} />
                      </Button>
                      <span className="text-sm font-medium w-8 text-center">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus size={14} />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>₹{calculateTotal()}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <div className="border-t pt-2 mt-2">
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>₹{calculateTotal()}</span>
              </div>
            </div>
          </div>

          <Link href="/checkout">
            <Button className="w-full mt-4">Proceed to Checkout</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
