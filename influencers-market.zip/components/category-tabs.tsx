"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface CategoryTabsProps {
  onCategoryChange: (category: string) => void
}

export function CategoryTabs({ onCategoryChange }: CategoryTabsProps) {
  const [activeCategory, setActiveCategory] = useState("all")

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category)
    onCategoryChange(category)
  }

  return (
    <Tabs defaultValue="all" className="mb-6" onValueChange={handleCategoryChange}>
      <TabsList className="grid grid-cols-4 w-full">
        <TabsTrigger value="all" className="text-xs">
          All Products
        </TabsTrigger>
        <TabsTrigger value="fashion" className="text-xs">
          Fashion
        </TabsTrigger>
        <TabsTrigger value="beauty" className="text-xs">
          Beauty
        </TabsTrigger>
        <TabsTrigger value="other" className="text-xs">
          Other Tools
        </TabsTrigger>
      </TabsList>
    </Tabs>
  )
}
