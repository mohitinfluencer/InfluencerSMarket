"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Users, ShoppingBag, Search, PlusCircle, BarChart3 } from "lucide-react"

export function AdminBottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2 z-10">
      <Link
        href="/admin/users"
        className={`flex flex-col items-center p-2 ${pathname === "/admin/users" ? "text-primary" : "text-gray-500"}`}
      >
        <Users size={20} />
        <span className="text-xs mt-1">Users</span>
      </Link>

      <Link
        href="/admin/orders"
        className={`flex flex-col items-center p-2 ${pathname === "/admin/orders" ? "text-primary" : "text-gray-500"}`}
      >
        <ShoppingBag size={20} />
        <span className="text-xs mt-1">Orders</span>
      </Link>

      <Link
        href="/admin/search"
        className={`flex flex-col items-center p-2 ${pathname === "/admin/search" ? "text-primary" : "text-gray-500"}`}
      >
        <Search size={20} />
        <span className="text-xs mt-1">Search</span>
      </Link>

      <Link
        href="/admin/add"
        className={`flex flex-col items-center p-2 ${pathname === "/admin/add" ? "text-primary" : "text-gray-500"}`}
      >
        <PlusCircle size={20} />
        <span className="text-xs mt-1">Add</span>
      </Link>

      <Link
        href="/admin/analytics"
        className={`flex flex-col items-center p-2 ${pathname === "/admin/analytics" ? "text-primary" : "text-gray-500"}`}
      >
        <BarChart3 size={20} />
        <span className="text-xs mt-1">Analytics</span>
      </Link>
    </nav>
  )
}
