"use client"

import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function Header() {
  return (
    <header>
      <div className="bg-[#6366f1] text-white py-6 text-center">
        <h1 className="text-3xl font-bold mb-1">InfluencersMarket</h1>
        <p className="text-sm opacity-90">Shop from Your Favorite Creators</p>
      </div>
      <div className="container mx-auto px-4 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input
            type="text"
            placeholder="Search products, influencers..."
            className="pl-10 border-gray-200 rounded-full shadow-sm"
          />
        </div>
      </div>
    </header>
  )
}
