"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Product } from "@/lib/types"
import { ShoppingCart, Star, ChevronLeft, ChevronRight } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface ProductDetailProps {
  product: Product
}

export function ProductDetail({ product }: ProductDetailProps) {
  const router = useRouter()
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined,
  )
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product.colors && product.colors.length > 0 ? product.colors[0] : undefined,
  )

  const handleAddToCart = () => {
    // In a real app, you'd add this to your cart state/database
    const cartItems = JSON.parse(localStorage.getItem("cartItems") || "[]")
    const existingItem = cartItems.find(
      (item: any) =>
        item.product.id === product.id && item.selectedSize === selectedSize && item.selectedColor === selectedColor,
    )

    if (existingItem) {
      existingItem.quantity += 1
    } else {
      cartItems.push({
        id: `cart_${Date.now()}`,
        product: product,
        quantity: 1,
        selectedSize,
        selectedColor,
      })
    }

    localStorage.setItem("cartItems", JSON.stringify(cartItems))

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    })
  }

  const handleBuyNow = () => {
    // Add to cart and redirect to checkout
    handleAddToCart()
    router.push("/checkout")
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length)
  }

  return (
    <div className="mb-8">
      <div className="relative h-64 md:h-80 rounded-lg overflow-hidden mb-4">
        <Image
          src={product.images[currentImageIndex] || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover"
        />
        {product.images.length > 1 && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/70 hover:bg-white/90 rounded-full"
              onClick={prevImage}
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/70 hover:bg-white/90 rounded-full"
              onClick={nextImage}
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          </>
        )}
      </div>

      {product.images.length > 1 && (
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
          {product.images.map((image, index) => (
            <div
              key={index}
              className={`relative w-16 h-16 rounded cursor-pointer border-2 ${
                index === currentImageIndex ? "border-[#6366f1]" : "border-gray-200"
              }`}
              onClick={() => setCurrentImageIndex(index)}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`${product.name} - view ${index + 1}`}
                fill
                className="object-cover rounded"
              />
            </div>
          ))}
        </div>
      )}

      <h1 className="text-2xl font-bold mb-2">{product.name}</h1>

      <div className="flex items-center mb-2">
        <div className="flex">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              size={18}
              className={i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
            />
          ))}
        </div>
        <span className="text-sm text-gray-500 ml-2">
          {product.rating} ({product.reviews} reviews)
        </span>
      </div>

      <div className="flex justify-between items-center mb-4">
        <span className="text-2xl font-bold text-[#6366f1]">₹{product.price}</span>
        <span className="text-gray-500">By {product.creatorName}</span>
      </div>

      {product.sizes && product.sizes.length > 0 && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Size</label>
          <Select value={selectedSize} onValueChange={setSelectedSize}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select size" />
            </SelectTrigger>
            <SelectContent>
              {product.sizes.map((size) => (
                <SelectItem key={size} value={size}>
                  {size}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {product.colors && product.colors.length > 0 && (
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Color</label>
          <Select value={selectedColor} onValueChange={setSelectedColor}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select color" />
            </SelectTrigger>
            <SelectContent>
              {product.colors.map((color) => (
                <SelectItem key={color} value={color}>
                  {color}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="space-y-3 mb-6">
        <Button className="w-full bg-[#6366f1] hover:bg-[#5457e5]" size="lg" onClick={handleBuyNow}>
          Buy Now
        </Button>
        <Button
          variant="outline"
          className="w-full flex items-center justify-center border-[#6366f1] text-[#6366f1] hover:bg-[#6366f1] hover:text-white"
          size="lg"
          onClick={handleAddToCart}
        >
          <ShoppingCart className="mr-2" size={18} />
          Add to Cart
        </Button>
      </div>

      {/* Product Description Card */}
      <Card>
        <CardHeader>
          <CardTitle>Product Description</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">{product.description}</p>

          <div className="mt-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Category:</span>
              <span className="text-sm font-medium capitalize">{product.category.replace("-", " ")}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Creator:</span>
              <span className="text-sm font-medium">{product.creatorName}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
